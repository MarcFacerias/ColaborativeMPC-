%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Author: Eugenio Alcala Baselga
% Date: 21/12/2018
% ~ LPV - MPC - Planner
% INFORMATION about the codes on this folder
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Llegados a este punto vamos a introducir obstaculos estaticos.

% La deteccion del obstaculo la va a realizar un ente superior al
% planificador. Este agente externo se va a encargar de suministrar al
% planner el perfil del limite de la carretera correspondiente en funcion
% del obstaculo.



