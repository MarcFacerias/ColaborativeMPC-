map = MapMod("oval"); 

initializeFigure_xy(map );

