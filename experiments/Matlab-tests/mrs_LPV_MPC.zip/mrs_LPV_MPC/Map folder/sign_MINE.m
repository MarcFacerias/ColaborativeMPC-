function [ res ] = sign( a )

    if a >= 0
        res = 1;
    else
        res = -1;
    end

end
