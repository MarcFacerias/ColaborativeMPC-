% MPT3 modules
%
% Files
%   mpt_subModules - additional properties, depending on the directory structure
