#define _GLIBCXX_USE_C99 1
#include <ros/ros.h>
#include "std_msgs/String.h"
#include <ar_track_alvar_msgs/AlvarMarkers.h>
#include <geometry_msgs/PoseStamped.h>
#include <std_msgs/Bool.h>
#include <tf2_ros/transform_listener.h>
#include "tf2/transform_datatypes.h"
#include <iterator>
#include <vector>
#include <sstream>
#include <deque>
#include <string>
#include <sstream>
#include <l4vehicle_msgs/VehicleState.h>
#include <lpv_mpc/ECU.h>
#include <lpv_mpc/pos_info.h>
#include <lpv_mpc/errors_info.h>
#include <lpv_mpc/simulatorStates.h>
#include <ros/console.h>
#include <std_msgs/Bool.h>
#include <Eigen/Dense>
#include <ctime>
#include <math.h>
#include <fstream>
#include <iterator>
#include <vector>
#include <estimator/lmi_data.h>
#include <iostream>
#include <chrono>
#include <unistd.h>
#include<Eigen/Core>
#include<Eigen/SVD>
using namespace Eigen;

////////////////////////////classes////////////////////////////
class GetSensorData{

  public:
    float x = 0;
    float y = 0;
    float yaw = 0;
    float psiDot = 0;
    float vx = 0;
    ros::NodeHandle n;
    ros::Subscriber pose_sub;

    GetSensorData(){

      pose_sub = n.subscribe("/sensorStates", 1000, &GetSensorData::GetPoseCallback, this);

    }

    void GetPoseCallback(const lpv_mpc::simulatorStates& msg)
    {

        x       = msg.x;
        y       = msg.y;
        yaw     = msg.psi;
        vx      = msg.vx;
        psiDot  = msg.psiDot;

    }

};

class GetGroundTruthData{

  public:
    float x = 0;
    float y = 0;
    float yaw = 0;
    float psiDot = 0;
    float vx = 0;
    float vy = 0;
    std::list <float> x_hist;
    std::list <float> y_hist;
    std::list <float> vx_hist;
    std::list <float> vy_hist;
    std::list <float> yaw_hist;
    std::list <float> psiDot_hist;
    ros::NodeHandle n;
    ros::Subscriber groundTruth_sub;

    GetGroundTruthData(){

      groundTruth_sub = n.subscribe("/vehicle_state", 1000, &GetGroundTruthData::GetGroundTruthDataCallback, this);

    }

    void GetGroundTruthDataCallback(const l4vehicle_msgs::VehicleState& msg)
    {

        x       = msg.x;
        y       = msg.y;
        yaw     = msg.heading;
        vx      = msg.longitudinal_velocity;
        vy      = msg.lateral_velocity;
        psiDot  = msg.angular_velocity;
        x_hist.push_back(x);
        y_hist.push_back(y);
        yaw_hist.push_back(yaw);
        vx_hist.push_back(vx);
        vy_hist.push_back(vy);
        psiDot_hist.push_back(psiDot);

    }

};

class GetActuData{

  public:

    float a  = 1.0;
    float steer = 0.15;
    ros::Subscriber actu_sub;
    ros::NodeHandle n;

    GetActuData(){

      actu_sub = n.subscribe("/ecu", 1000, &GetActuData::GetActuCallback, this);

    }

    private:

    void GetActuCallback(const lpv_mpc::ECU& msg)
    {

        a     = msg.motor;
        steer = msg.servo;

    }

};

void FlagCallback(const std_msgs::Bool& msg){

  flag = msg.data;

}

class ObserverLPV{

  public:

    //handlers
    ros::NodeHandle n;

    //Clients
    ros::ServiceClient client;
    estimator::lmi_data srv;

    // model dimension variables
    float n_states = 6;
    float n_outputs = 5;
    float n_control = 2;

    //general usage variables
    MatrixXf eye6;

    //vehicle variables

    float lf;
    float lr;
    float m;
    float I;
    float Cf;
    float Cr;
    float mu;
    float et = 0;

    //matrices
    MatrixXf C;
    MatrixXf A;
    MatrixXf B;
    MatrixXf Aln;
    MatrixXf Bln;
    MatrixXf L;
    MatrixXf Rxxio;
    MatrixXf shape_priori;

    //Vectors
    VectorXf Ew;
    VectorXf Ev;
    VectorXf u;
    VectorXf mu_sch;

    //DATA from matlab
    std::vector<MatrixXf> Llmi;
    std::vector<std::vector<float>> sched_vars;

    //estimated states
    float x      = 0.02;
    float y      = 0.0;
    float vx     = 0.75;
    float vy     = 0.0;
    float yaw    = 0.0;
    float psiDot = 0.0;
    VectorXf states_est;

    //historic of values
    std::list <float> x_est_hist;
    std::list <float> y_est_hist;
    std::list <float> vx_est_hist;
    std::list <float> vy_est_hist;
    std::list <float> yaw_est_hist;
    std::list <float> psiDot_est_hist;
    std::list <std::vector<float>> est_error_hist;

    void estimateState(GetSensorData sensor, GetActuData ecu)

    ObserverLPV()

    private:

    void LoadMatrices()

    // void AB_computation(MatrixXf &A, MatrixXf &B, float theta, float steer, float vx, float vy){
    void AB_computation(float steer)

    // void L_computation(MatrixXf &L, float vx, float vy, float theta, float steer){
    void L_computation(float steer)
};

class ObserverLPVi{

  public:

    //handlers
    ros::NodeHandle n;

    //Clients
    ros::ServiceClient client;
    estimator::lmi_data srv;

    // model dimension variables
    float n_states = 6;
    float n_outputs = 5;
    float n_control = 2;

    //general usage variables
    MatrixXf eye6 = MatrixXf::Identity(n_states, n_states);

    //vehicle variables

    float lf;
    float lr;
    float m;
    float I;
    float Cf;
    float Cr;
    float mu;
    float et = 0;

    //matrices
    MatrixXf C;
    MatrixXf A;
    MatrixXf B;
    MatrixXf Aln;
    MatrixXf Bln;
    MatrixXf Ew_diag = MatrixXf::Zero(n_states, n_states);
    MatrixXf Ev_diag = MatrixXf::Zero(n_outputs,n_outputs);
    MatrixXf L;
    MatrixXf Rxio = eye6;

    //Vectors
    VectorXf Ew;
    VectorXf Ev;
    VectorXf u;
    VectorXf mu_sch;

    //DATA from matlab
    std::vector<MatrixXf> Llmi;
    std::vector<std::vector<float>> sched_vars;

    //estimated states
    float x      = 0.0;
    float y      = 0.0;
    float vx     = 1.0112;
    float vy     = 0.0115;
    float yaw    = 0.0;
    float psiDot = 0.0946;
    VectorXf states_est;


    //historic of values
    std::list <float> x_est_hist;
    std::list <float> y_est_hist;
    std::list <float> vx_est_hist;
    std::list <float> vy_est_hist;
    std::list <float> yaw_est_hist;
    std::list <float> psiDot_est_hist;
    std::list <std::vector<float>> est_error_hist;
    std::list <std::vector<float>> upper_limits;
    std::list <std::vector<float>> lower_limits;

    void estimateState(GetSensorData sensor, GetActuData ecu)

    ObserverLPVi()

    private:

    void LoadMatrices()

    // void AB_computation(MatrixXf &A, MatrixXf &B, float theta, float steer, float vx, float vy){
    void AB_computation(float steer)

    // void L_computation(MatrixXf &L, float vx, float vy, float theta, float steer){
    void L_computation(float steer)
};

/////////////////////////functions//////////////////////////

VectorXf sort_indexes(const VectorXf v) 

MatrixXf EnvBox(MatrixXf Rxxio)

MatrixXf reduction(MatrixXf Rxio, int n_dim)

class ComputeError{

	public:

  ros::Publisher error_pub;
  ros::NodeHandle n;
  std::vector<lpv_mpc::simulatorStates> errors;
  std::vector<float> rmse;

  ComputeError(){

    error_pub = n.advertise<lpv_mpc::errors_info>("errors", 5);

  }
				/////////////////////////////////////////
				  //Overloaded function definition ///
				////////////////////////////////////////

  				//////////////ObserverLPV///////////////

  void compute_error(GetGroundTruthData truth,ObserverLPV estimator){

    lpv_mpc::simulatorStates temp;

    temp.vx = truth.vx - estimator.vx;
    temp.vy = truth.vy - estimator.vy;
    temp.psiDot = truth.psiDot - estimator.psiDot;
    temp.x = truth.x - estimator.x;
    temp.y = truth.y - estimator.y;
    temp.psi = truth.yaw - estimator.yaw;

    ROS_ERROR_STREAM("Ground Truth: x " << truth.x <<" y "<< truth.y <<" yaw " << truth.yaw <<" vx " << truth.vx
                      <<" vy "<< truth.vy <<" yaw " << truth.yaw <<" psiDot " << truth.psiDot);

    errors.push_back(temp);
  };

  void save_error(GetGroundTruthData truth,ObserverLPV estimator){

    lpv_mpc::errors_info msg;
    msg.rmse = rmse;

    for (int i = 0; i < errors.size(); i++ ){

      msg.err.push_back(errors[i]);

    }

    error_pub.publish(msg);

  };

  				//////////////ObserverLPVi//////////////

    void compute_error(GetGroundTruthData truth,ObserverLPVi estimator){

    lpv_mpc::simulatorStates temp;

    temp.vx = truth.vx - estimator.vx;
    temp.vy = truth.vy - estimator.vy;
    temp.psiDot = truth.psiDot - estimator.psiDot;
    temp.x = truth.x - estimator.x;
    temp.y = truth.y - estimator.y;
    temp.psi = truth.yaw - estimator.yaw;

    ROS_ERROR_STREAM("Ground Truth: x " << truth.x <<" y "<< truth.y <<" yaw " << truth.yaw <<" vx " << truth.vx
                      <<" vy "<< truth.vy <<" yaw " << truth.yaw <<" psiDot " << truth.psiDot);

    errors.push_back(temp);
  };

  void save_error(GetGroundTruthData truth,ObserverLPVi estimator){

    lpv_mpc::errors_info msg;
    msg.rmse = rmse;

    for (int i = 0; i < errors.size(); i++ ){

      msg.err.push_back(errors[i]);

    }

    error_pub.publish(msg);

  };


			  /////////////////////////////////////////
			 //END OF Overloaded function definition//
			/////////////////////////////////////////


  void compute_rmse(std::vector<lpv_mpc::simulatorStates> errors){


    float error_x = 0;
    float error_y = 0;
    float error_psi = 0;
    float error_vx = 0;
    float error_vy = 0;
    float error_psiDot = 0;
    float numel = 0;

    for (int i = 0; i < errors.size(); i++)
      {
      	// Access the object through iterator

        error_x      += errors[i].x*errors[i].x;
        error_y      += errors[i].y*errors[i].y;
        error_psi    += errors[i].psi*errors[i].psi;
        error_vx     += errors[i].vx*errors[i].vx;
        error_vy     += errors[i].vy*errors[i].vy;
        error_psiDot += errors[i].psiDot*errors[i].psiDot;

        numel++;
      }

    rmse = { sqrt(error_x/numel), sqrt(error_y/numel), sqrt(error_psi/numel),
             sqrt(error_vx/numel), sqrt(error_vy/numel), sqrt(error_psiDot/numel)};


  }

};