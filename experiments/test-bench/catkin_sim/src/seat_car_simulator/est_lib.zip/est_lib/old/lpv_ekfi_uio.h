#include <Eigen/SVD>

template<typename _Matrix_Type_>
bool pseudoInverse(const _Matrix_Type_ &a, _Matrix_Type_ &result, double epsilon = std::numeric_limits<typename _Matrix_Type_::Scalar>::epsilon())
{
  if(a.rows()<a.cols())
      return false;

  Eigen::JacobiSVD< _Matrix_Type_ > svd = a.jacobiSvd();

  typename _Matrix_Type_::Scalar tolerance = epsilon * std::max(a.cols(), a.rows()) * svd.singularValues().array().abs().maxCoeff();

  result = svd.matrixV() * _Matrix_Type_(_Matrix_Type_( (svd.singularValues().array().abs() > tolerance).select(svd.singularValues().
      array().inverse(), 0) ).diagonal()) * svd.matrixU().adjoint();
}

class ObserverLPVi_UIO{

  public:

    //handlers
    ros::NodeHandle n;

    //Clients
    ros::ServiceClient client = n.serviceClient<estimator::lmi_data>("LoadMatrices");
    estimator::lmi_data srv;

    // model dimension variables
    float n_states = 6;
    float n_outputs = 5;
    float n_control = 2;

    //general usage variables
    MatrixXf eye6 = MatrixXf::Identity(n_states, n_states);

    //vehicle variables

    float lf;
    float lr;
    float m;
    float I;
    float Cf;
    float Cr;
    float mu;
    float et = 0;

    //matrices
    MatrixXf C;
    MatrixXf A;
    MatrixXf B;
    MatrixXf Aln;
    MatrixXf Bln;
    MatrixXf A_uio;
    MatrixXf B_uio;
    MatrixXf L;
    MatrixXf Rxio = eye6;

    //Vectors
    VectorXf Ew;
    VectorXf Ev;
    VectorXf E;
    VectorXf u;
    VectorXf y_ant;
    VectorXf tau;
    VectorXf mu_sch;

    //DATA from matlab
    std::vector<MatrixXf> Llmi;
    std::vector<std::vector<float>> sched_vars;

    //estimated states
    float x      = 0.0;
    float y      = 0.0;
    float vx     = 1.0112;
    float vy     = 0.0115;
    float yaw    = 0.0;
    float psiDot = 0.0946;
    VectorXf states_est;


    //historic of values
    std::list <float> x_est_hist;
    std::list <float> y_est_hist;
    std::list <float> vx_est_hist;
    std::list <float> vy_est_hist;
    std::list <float> yaw_est_hist;
    std::list <float> psiDot_est_hist;
    std::list <std::vector<float>> est_error_hist;
    std::list <std::vector<float>> upper_limits;
    std::list <std::vector<float>> lower_limits;

    void estimateState(GetSensorData sensor, GetActuData ecu){

      VectorXf y_meas;

      y_meas.resize(n_outputs);
      y_meas(0) = sensor.vx;
      y_meas(1) = sensor.psiDot;
      y_meas(2) = sensor.x;
      y_meas(3) = sensor.y;
      y_meas(4) = sensor.yaw;

      u(0)      = ecu.steer;
      u(1)      = ecu.a;

      // update matrices
      AB_computation(u(0));

      L_computation(u(0));
      // std::cout << u << std::endl << "\n";
      // std::cout << Aln << std::endl << "\n";
      //priori estimation


      VectorXf dy          = (y_meas - y_ant)/dt;
      VectorXf dis_est_max = tau*(dy - C*(A*states_est + B*u + Ew) - Ev);
      VectorXf dis_est_min = tau*(dy - C*(A*states_est + B*u - Ew) + Ev);

      MatrixXf prior = A_uio*states_est + B_uio*u;

      std::cout << L << std::endl << "\n";
      states_est = prior + L * (y_meas - C*prior) + E*tau*y_meas;

      //Expansion Matrices
      MatrixXf shape_priori;
      shape_priori.resize(int(A_uio.rows()),int(Rxio.cols()+1));

      shape_priori << A_uio*Rxio, Ew;

      Rxio.resize(int(n_states), shape_priori.cols() + 1);

      MatrixXf aux_mat;
      aux_mat.resize(int(n_states), shape_priori.cols() + 1);
      aux_mat << (eye6 - L*C)*shape_priori, (-E*tau - L)*Ev;
      Rxio = aux_mat;

      MatrixXf LimitMatrix = EnvBox(Rxio);

      std::vector<float> aux_vec_max;
      std::vector<float> aux_vec_min;

      for (int i = 0; i < n_states; i++){

        aux_vec_max.push_back(states_est(i) + fabs(LimitMatrix(i,i)));
        aux_vec_min.push_back(states_est(i) - fabs(LimitMatrix(i,i)));

      }

      upper_limits.push_back(aux_vec_max);
      lower_limits.push_back(aux_vec_min);


      // std::cout << states_est;
      //save states
      vx      = states_est(0);
      vy      = states_est(1);
      psiDot  = states_est(2);
      x       = states_est(3);
      y       = states_est(4);
      yaw     = states_est(5);

        ROS_ERROR_STREAM("update finished: x " << x <<" y "<< y <<" yaw " << yaw <<" vx " << vx
                          <<" vy "<< vy <<" yaw " <<" psiDot " << psiDot);
        ROS_ERROR_STREAM("upper limits: x " << aux_vec_max[3] <<" y "<< aux_vec_max[4] <<" yaw " << aux_vec_max[5] <<" vx " << aux_vec_max[0]
                          <<" vy "<< aux_vec_max[1] <<" PsiYaw " <<" psiDot " << aux_vec_max[2]);
        ROS_ERROR_STREAM("lower limits: x " << aux_vec_min[3] <<" y "<< aux_vec_min[4] <<" yaw " << aux_vec_min[5] <<" vx " << aux_vec_min[0]
                          <<" vy "<< aux_vec_min[1] <<" PsiYaw " <<" psiDot " << aux_vec_min[2]);

      x_est_hist.push_back(x);
      y_est_hist.push_back(y);
      yaw_est_hist.push_back(yaw);
      vx_est_hist.push_back(vx);
      vy_est_hist.push_back(vy);
      psiDot_est_hist.push_back(psiDot);
        // std::cout<<A<<std::endl;
        // // std::cout<<B<<std::endl;
        // std::cout<<states_est<<std::endl;
    }

    ObserverLPVi_UIO(){

      A.resize(n_states,n_states);
      B.resize(n_states,n_control);
      Aln.resize(n_states,n_states);
      Bln.resize(n_states,n_control);
      A_uio.resize(n_states,n_states);
      B_uio.resize(n_states,n_control);
      C.resize(n_outputs,n_states);
      L.resize(n_states,n_outputs);
      Ew.resize(n_states);
      E.resize(n_states);
      Ev.resize(n_outputs);
      u.resize(n_control);
      states_est.resize(n_states);

      n.getParam("lf",lf);
      n.getParam("lr", lr);
      n.getParam("m", m);
      n.getParam("Iz",I);
      n.getParam("Cf",Cf);
      n.getParam("Cr",Cr);
      n.getParam("mu",mu);

      C << 1, 0, 0, 0, 0, 0,
           0, 0, 1, 0, 0, 0,
           0, 0, 0, 1, 0, 0,
           0, 0, 0, 0, 1, 0,
           0, 0, 0, 0, 0, 1;

      A << 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0;

      B << 0, 1,
           0, 0,
           0, 0,
           0, 0,
           0, 0,
           0, 0;

      u << 0,0;

      Ew << 0.05   ,0.03   ,0.03  ,0.25  ,0.25 ,0.25 ;
      E  << 0.05   ,0.03   ,0.03  ,0.25  ,0.25 ,0.25 ;
      Ev << 0.01   ,0.02   ,0.02  ,0.01  ,0.01;
      pseudoInverse(C*E,tau);

      states_est << vx, vy, psiDot, x, y, yaw;
      LoadMatrices();
    }

    private:

    void LoadMatrices(){

      srv.request.est_id = "LPV";
      client.call(srv);

      ROS_ERROR_STREAM("resize v" << srv.response.L.size());
      Llmi.resize(srv.response.L.size());

      // fill LMIs
      for (int i = 0; i < srv.response.L.size(); i++){

        Llmi[i].resize(n_states,n_outputs);

        for (int rows = 0; rows < n_states; rows++){

          for (int cols = 0; cols < n_outputs; cols++){

            Llmi[i](rows,cols) = srv.response.L[i].gains[rows*(n_states-1) + cols];

          }
        }
      }

      //fill sched_vars

      sched_vars.resize(srv.response.limits.max.size());

      mu_sch.resize(srv.response.L.size());

      for (int i = 0; i < srv.response.limits.max.size(); i++){

        sched_vars[i].push_back(srv.response.limits.min[i]);
        sched_vars[i].push_back(srv.response.limits.max[i]);

      }

    }

    // void AB_computation(MatrixXf &A, MatrixXf &B, float theta, float steer, float vx, float vy){
    void AB_computation(float steer){

      //update B
      B(0,0) = -sin(steer) * Cf/m;
      B(1,0) = (cos(steer) * Cf) / m;
      B(2,0) = (lf * Cf * cos(steer)) / I;
      // B(1,1) = cos(steer);
      // B(2,1) = sin(steer);

      //Update A
      A(0,0) =  -mu;
      A(0,1) = (sin(steer) * Cf) / (m*vx);
      A(0,2) = (sin(steer) * Cf * lf) / (m*vx) + vy;
      A(1,1) = -(Cr + Cf * cos(steer)) / (m*vx);
      A(1,2) = -(lf * Cf * cos(steer) - lr * Cr) / (m*vx) - vx;
      A(2,1) = -(lf * Cf * cos(steer) - lr * Cr) / (I*vx);
      A(2,2) = -(lf * lf * Cf * cos(steer) + lr * lr * Cr) / (I*vx);
      A(3,0) = cos(yaw);
      A(4,0) = sin(yaw);
      A(3,1) = -sin(yaw);
      A(4,1) = cos(yaw);
      A(5,2) = 1;

      Aln = eye6 + (A*dt);
      Bln = B*dt;

      A_uio =(eye6 - E*tau*C)*Aln;
      B_uio =(eye6 - E*tau*C)*Bln;

    }

    // void L_computation(MatrixXf &L, float vx, float vy, float theta, float steer){
    void L_computation(float steer){

      float M_vx_despl_min    = (sched_vars[0][1] - vx)    / (sched_vars[0][1] - sched_vars[0][0]);
      float M_vy_despl_min    = (sched_vars[1][1] - vy)    / (sched_vars[1][1] - sched_vars[1][0]);
      float M_steer_min       = (sched_vars[3][1] - steer) / (sched_vars[3][1] - sched_vars[3][0]);
      float M_theta_min       = (sched_vars[5][1] - yaw) / (sched_vars[5][1] - sched_vars[5][0]);

      mu_sch[0]               = M_vx_despl_min         * M_vy_despl_min      * M_steer_min      *  M_theta_min;
      mu_sch[1]               = M_vx_despl_min         * M_vy_despl_min      * M_steer_min      *  (1-M_theta_min);
      mu_sch[2]               = M_vx_despl_min         * M_vy_despl_min      * (1-M_steer_min)  *  M_theta_min;
      mu_sch[3]               = M_vx_despl_min         * M_vy_despl_min      * (1-M_steer_min)  *  (1-M_theta_min);
      mu_sch[4]               = M_vx_despl_min         * (1-M_vy_despl_min)  * M_steer_min      *  M_theta_min;
      mu_sch[5]               = M_vx_despl_min         * (1-M_vy_despl_min)  * M_steer_min      *  (1-M_theta_min);
      mu_sch[6]               = M_vx_despl_min         * (1-M_vy_despl_min)  * (1-M_steer_min)  *  M_theta_min;
      mu_sch[7]               = M_vx_despl_min         * (1-M_vy_despl_min)  * (1-M_steer_min)  *  (1-M_theta_min);

      mu_sch[8]               = (1-M_vx_despl_min)     * M_vy_despl_min      * M_steer_min      *  M_theta_min;
      mu_sch[9]               = (1-M_vx_despl_min)     * M_vy_despl_min      * M_steer_min      *  (1-M_theta_min);
      mu_sch[10]              = (1-M_vx_despl_min)     * M_vy_despl_min      * (1-M_steer_min)  *  M_theta_min;
      mu_sch[11]              = (1-M_vx_despl_min)     * M_vy_despl_min      * (1-M_steer_min)  *  (1-M_theta_min);
      mu_sch[12]              = (1-M_vx_despl_min)     * (1-M_vy_despl_min)  * M_steer_min      *  M_theta_min;
      mu_sch[13]              = (1-M_vx_despl_min)     * (1-M_vy_despl_min)  * M_steer_min      *  (1-M_theta_min);
      mu_sch[14]              = (1-M_vx_despl_min)     * (1-M_vy_despl_min)  * (1-M_steer_min)  *  M_theta_min;
      mu_sch[15]              = (1-M_vx_despl_min)     * (1-M_vy_despl_min)  * (1-M_steer_min)  *  (1-M_theta_min);

      MatrixXf result = MatrixXf::Zero(n_states,n_outputs);

      for (int i = 0; i < 15; i++){

          result += mu_sch[i] * Llmi[i];

      }

      L = -result*dt;
      // std::cout << L << std::endl;
    }
};
