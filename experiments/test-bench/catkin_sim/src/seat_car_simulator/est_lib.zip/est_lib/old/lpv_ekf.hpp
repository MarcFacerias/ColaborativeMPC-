
class ObserverLPV{

  public:

    //handlers
    ros::NodeHandle n;

    //Clients
    ros::ServiceClient client = n.serviceClient<estimator::lmi_data>("LoadMatrices");
    estimator::lmi_data srv;

    // model dimension variables
    float n_states = 6;
    float n_outputs = 5;
    float n_control = 2;

    //general usage variables
    MatrixXf eye6 = MatrixXf::Identity(n_states, n_states);

    //vehicle variables

    float lf;
    float lr;
    float m;
    float I;
    float Cf;
    float Cr;
    float mu;
    float et = 0;

    //matrices
    MatrixXf C;
    MatrixXf A;
    MatrixXf B;
    MatrixXf Aln;
    MatrixXf Bln;
    MatrixXf L;
    MatrixXf Rxxio;
    MatrixXf shape_priori;

    //Vectors
    VectorXf Ew;
    VectorXf Ev;
    VectorXf u;
    VectorXf mu_sch;

    //DATA from matlab
    std::vector<MatrixXf> Llmi;
    std::vector<std::vector<float>> sched_vars;

    //estimated states
    float x      = 0.0;
    float y      = 0.0;
    float vx     = 1.0112;
    float vy     = 0.0115;
    float yaw    = 0.0;
    float psiDot = 0.0946;
    VectorXf states_est;

    //historic of values
    std::list <float> x_est_hist;
    std::list <float> y_est_hist;
    std::list <float> vx_est_hist;
    std::list <float> vy_est_hist;
    std::list <float> yaw_est_hist;
    std::list <float> psiDot_est_hist;

    void estimateState(GetSensorData sensor, GetActuData ecu){

      VectorXf y_meas;

      y_meas.resize(n_outputs);
      y_meas(0) = sensor.vx;
      y_meas(1) = sensor.psiDot;
      y_meas(2) = sensor.x;
      y_meas(3) = sensor.y;
      y_meas(4) = sensor.yaw;

      u(0)      = ecu.steer;
      u(1)      = ecu.a;

      // update matrices
      AB_computation(u(0));

      L_computation(u(0));
      // std::cout << u << std::endl << "\n";
      // std::cout << Aln << std::endl << "\n";
      //priori estimation


      MatrixXf prior = Aln*states_est + Bln*u;
      std::cout << (y_meas - C*prior) << std::endl << "\n";

      std::cout << L << std::endl << "\n";
      states_est = prior + L * (y_meas - C*prior);
      // std::cout << states_est;
      //save states
      vx      = states_est(0);
      vy      = states_est(1);
      psiDot  = states_est(2);
      x       = states_est(3);
      y       = states_est(4);
      yaw     = states_est(5);

        ROS_ERROR_STREAM("update finished: x " << x <<" y "<< y <<" yaw " << yaw <<" vx " << vx
                          <<" vy "<< vy <<" yaw " <<" psiDot " << psiDot);

      x_est_hist.push_back(x);
      y_est_hist.push_back(y);
      yaw_est_hist.push_back(yaw);
      vx_est_hist.push_back(vx);
      vy_est_hist.push_back(vy);
      psiDot_est_hist.push_back(psiDot);
        // std::cout<<A<<std::endl;
        // // std::cout<<B<<std::endl;
        // std::cout<<states_est<<std::endl;
    }

    ObserverLPV(){

      A.resize(n_states,n_states);
      B.resize(n_states,n_control);
      Aln.resize(n_states,n_states);
      Bln.resize(n_states,n_control);
      C.resize(n_outputs,n_states);
      L.resize(n_states,n_outputs);
      Ew.resize(n_states);
      Ev.resize(n_outputs);
      u.resize(n_control);
      states_est.resize(n_states);

      n.getParam("lf",lf);
      n.getParam("lr", lr);
      n.getParam("m", m);
      n.getParam("Iz",I);
      n.getParam("Cf",Cf);
      n.getParam("Cr",Cr);
      n.getParam("mu",mu);

      C << 1, 0, 0, 0, 0, 0,
           0, 0, 1, 0, 0, 0,
           0, 0, 0, 1, 0, 0,
           0, 0, 0, 0, 1, 0,
           0, 0, 0, 0, 0, 1;

      A << 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0;

      B << 0, 1,
           0, 0,
           0, 0,
           0, 0,
           0, 0,
           0, 0;

      u << 0,0;

      Ew << 1, 0, 0, 0, 0, 0;
      Ev << 1, 0, 0, 0, 0;

      states_est << vx, vy, psiDot, x, y, yaw;
      LoadMatrices();
    }

    private:

    void LoadMatrices(){

      srv.request.est_id = "LPV";
      client.call(srv);

      ROS_ERROR_STREAM("resize v" << srv.response.L.size());
      Llmi.resize(srv.response.L.size());

      // fill LMIs
      for (int i = 0; i < srv.response.L.size(); i++){

        Llmi[i].resize(n_states,n_outputs);

        for (int rows = 0; rows < n_states; rows++){

          for (int cols = 0; cols < n_outputs; cols++){

            Llmi[i](rows,cols) = srv.response.L[i].gains[rows*(n_states-1) + cols];

          }
        }
      }

      //fill sched_vars

      sched_vars.resize(srv.response.limits.max.size());

      mu_sch.resize(srv.response.L.size());

      for (int i = 0; i < srv.response.limits.max.size(); i++){

        sched_vars[i].push_back(srv.response.limits.min[i]);
        sched_vars[i].push_back(srv.response.limits.max[i]);

      }

    }

    // void AB_computation(MatrixXf &A, MatrixXf &B, float theta, float steer, float vx, float vy){
    void AB_computation(float steer){

      //update B
      B(0,0) = -sin(steer) * Cf/m;
      B(1,0) = (cos(steer) * Cf) / m;
      B(2,0) = (lf * Cf * cos(steer)) / I;
      // B(1,1) = cos(steer);
      // B(2,1) = sin(steer);

      //Update A
      A(0,0) =  -mu;
      A(0,1) = (sin(steer) * Cf) / (m*vx);
      A(0,2) = (sin(steer) * Cf * lf) / (m*vx) + vy;
      A(1,1) = -(Cr + Cf * cos(steer)) / (m*vx);
      A(1,2) = -(lf * Cf * cos(steer) - lr * Cr) / (m*vx) - vx;
      A(2,1) = -(lf * Cf * cos(steer) - lr * Cr) / (I*vx);
      A(2,2) = -(lf * lf * Cf * cos(steer) + lr * lr * Cr) / (I*vx);
      A(3,0) = cos(yaw);
      A(4,0) = sin(yaw);
      A(3,1) = -sin(yaw);
      A(4,1) = cos(yaw);
      A(5,2) = 1;

      Aln = eye6 + (A*dt);
      Bln = B*dt;
    }

    // void L_computation(MatrixXf &L, float vx, float vy, float theta, float steer){
    void L_computation(float steer){

      float M_vx_despl_min    = (sched_vars[0][1] - vx)    / (sched_vars[0][1] - sched_vars[0][0]);
      float M_vy_despl_min    = (sched_vars[1][1] - vy)    / (sched_vars[1][1] - sched_vars[1][0]);
      float M_steer_min       = (sched_vars[3][1] - steer) / (sched_vars[3][1] - sched_vars[3][0]);
      float M_theta_min       = (sched_vars[5][1] - yaw) / (sched_vars[5][1] - sched_vars[5][0]);

      mu_sch[0]               = M_vx_despl_min         * M_vy_despl_min      * M_steer_min      *  M_theta_min;
      mu_sch[1]               = M_vx_despl_min         * M_vy_despl_min      * M_steer_min      *  (1-M_theta_min);
      mu_sch[2]               = M_vx_despl_min         * M_vy_despl_min      * (1-M_steer_min)  *  M_theta_min;
      mu_sch[3]               = M_vx_despl_min         * M_vy_despl_min      * (1-M_steer_min)  *  (1-M_theta_min);
      mu_sch[4]               = M_vx_despl_min         * (1-M_vy_despl_min)  * M_steer_min      *  M_theta_min;
      mu_sch[5]               = M_vx_despl_min         * (1-M_vy_despl_min)  * M_steer_min      *  (1-M_theta_min);
      mu_sch[6]               = M_vx_despl_min         * (1-M_vy_despl_min)  * (1-M_steer_min)  *  M_theta_min;
      mu_sch[7]               = M_vx_despl_min         * (1-M_vy_despl_min)  * (1-M_steer_min)  *  (1-M_theta_min);

      mu_sch[8]               = (1-M_vx_despl_min)     * M_vy_despl_min      * M_steer_min      *  M_theta_min;
      mu_sch[9]               = (1-M_vx_despl_min)     * M_vy_despl_min      * M_steer_min      *  (1-M_theta_min);
      mu_sch[10]              = (1-M_vx_despl_min)     * M_vy_despl_min      * (1-M_steer_min)  *  M_theta_min;
      mu_sch[11]              = (1-M_vx_despl_min)     * M_vy_despl_min      * (1-M_steer_min)  *  (1-M_theta_min);
      mu_sch[12]              = (1-M_vx_despl_min)     * (1-M_vy_despl_min)  * M_steer_min      *  M_theta_min;
      mu_sch[13]              = (1-M_vx_despl_min)     * (1-M_vy_despl_min)  * M_steer_min      *  (1-M_theta_min);
      mu_sch[14]              = (1-M_vx_despl_min)     * (1-M_vy_despl_min)  * (1-M_steer_min)  *  M_theta_min;
      mu_sch[15]              = (1-M_vx_despl_min)     * (1-M_vy_despl_min)  * (1-M_steer_min)  *  (1-M_theta_min);

      MatrixXf result = MatrixXf::Zero(n_states,n_outputs);

      for (int i = 0; i < 15; i++){

          result += mu_sch[i] * Llmi[i];

      }

      L = -result*dt;
      // std::cout << L << std::endl;
    }
};
