#imports
from gazebo_msgs.msg import ModelState
from geometry_msgs.msg import Vector3, Quaternion

#ini vector, la Z depende del gazebo
link_msg.pose.position.z = 0.031
link_msg.twist.linear.x = 0.0
link_msg.twist.linear.y = 0
link_msg.twist.linear.z = 0

link_msg.twist.angular.x = 0.0
link_msg.twist.angular.y = 0
link_msg.twist.angular.z = 0

link_msg.model_name = "seat_car" #nombre del modelo
link_msg.reference_frame = "world"

#final del codigo
if pub_linkStates.get_num_connections() > 0:
    link_msg.pose.position.x = sim.x
    link_msg.pose.position.y = sim.y
    link_msg.pose.orientation = Quaternion(*quaternion_from_euler(0, 0, sim.yaw))

    pub_linkStates.publish(link_msg)