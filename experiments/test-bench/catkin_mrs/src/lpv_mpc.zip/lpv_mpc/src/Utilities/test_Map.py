from trackInitialization_mod import *

test_map = Map()