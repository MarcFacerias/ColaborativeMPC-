#!/usr/bin/env python
"""
    File name: LPV-MPC.py
    Author: Eugenio Alcala
    Email: eugenio.alcala@upc.edu.edu
    Date: 09/30/2018
    Python Version: 2.7.12 
"""

import os
import sys
import datetime
import rospy
import numpy as np
import scipy.io as sio
import pdb
import pickle
import matplotlib.pyplot as plt

sys.path.append(sys.path[0]+'/ControllerObject')
sys.path.append(sys.path[0]+'/Utilities')

from trackInitialization import wrap
#from barc.msg import ECU
from utilities import Regression, Curvature
from dataStructures import EstimatorData, PlanningData, ClosedLoopDataObj #used in simu, LMPCprediction #planning data-> sub a "my points"
from PathFollowingLPVMPC import PathFollowingLPV_MPC, ABC_computation_5SV
from l4vehicle_msgs.msg import ModelPredictiveControlCommand

np.set_printoptions(formatter={'float': lambda x: "{0:0.3f}".format(x)})


def main():

    rospy.init_node("LPV-MPC")

    input_commands  = rospy.Publisher('ModelPredictiveControlCommand', ModelPredictiveControlCommand, queue_size=1) #IDIADA
    #input_commands  = rospy.Publisher('ecu', ECU, queue_size=1) # Simulator

    mode            = rospy.get_param("/control/mode")
    N               = rospy.get_param("/control/N")
    Vx_ref          = rospy.get_param("/control/vel_ref")
    Cf_new          = rospy.get_param("Cf")  # lo dejamos de momento por sencillez pero no se usa en ningun sitio

    loop_rate       = rospy.get_param("/control/Hz")
    dt              = 1/loop_rate
    rate            = rospy.Rate(loop_rate)


    ## TODO: change this in order to be taken from the launch file
    Steering_Delay  = 0 
    Velocity_Delay  = 0

    #Steering_Delay  = int(rospy.get_param("/simulator/delay_df")/dt)

    NN_LPV_MPC      = False

#########################################################
#########################################################

    # # OFFLINE planning from LPV-MPP racing:
    # planning_path   = '/home/euge/GitHub/barc/workspace/src/barc/src/data/Planner_Refs'
    #
    # ## TRACK (OVAL, Racing Planner) : (30 July 19)
    # CURV_Planner    = sio.loadmat(planning_path+'/LPV_MPC_PLANNING_1_.mat')['pCURV']
    # VEL_Planner     = sio.loadmat(planning_path+'/LPV_MPC_PLANNING_1_.mat')['pnew_Vx']
    # X_Planner       = sio.loadmat(planning_path+'/LPV_MPC_PLANNING_1_.mat')['pxp']
    # Y_Planner       = sio.loadmat(planning_path+'/LPV_MPC_PLANNING_1_.mat')['pyp']
    # PSI_Planner     = sio.loadmat(planning_path+'/LPV_MPC_PLANNING_1_.mat')['pyaw']


#########################################################
#########################################################


    # Objects initializations

    #OL_predictions  = prediction()
    #rac_info        = Racing_Info()
    u_steer=0
    u_acc=0

    # Var sim
    # cmd=ECU()
    # cmd.servo       = 0.0
    # cmd.motor       = 0.0

    # Var IDIADA
    cmd_car = ModelPredictiveControlCommand()
    cmd_car.left_steer_turn_radius_reciprocal_command = 0
    cmd_car.acceleration_command = 0
    cmd_car.brake_deceleration_command = 0

    ClosedLoopData  = ClosedLoopDataObj(dt, 6000, 0)                     # Closed-Loop Data
    estimatorData   = EstimatorData()
    # map             = Map()                                              # Map -> we don't want to use it
    planning_data   = PlanningData()

    first_it        = 1
    NumberOfLaps    = 10
    LapNumber       = 0

    # Initialize variables for main loop
    GlobalState     = np.zeros(6)
    LocalState      = np.zeros(6)
    HalfTrack       = 0
    RunController   = 1
    Counter         = 0
    CounterRacing   = 0
    uApplied        = np.array([0.0, 0.0])
    oldU            = np.array([0.0, 0.0])

    RMSE_ve         = np.zeros(NumberOfLaps)
    RMSE_ye         = np.zeros(NumberOfLaps)
    RMSE_thetae     = np.zeros(NumberOfLaps)
    RMSE_acc_y      = np.zeros(NumberOfLaps)
    RMSE_matrix     = np.zeros(NumberOfLaps)
    Norm_matrix     = np.zeros((NumberOfLaps,3))


    vector_length   = 3000
    ALL_LOCAL_DATA  = np.zeros((vector_length,8))      # [vx vy psidot thetae s ye vxaccel vyaccel udelta uaccel]
    GLOBAL_DATA     = np.zeros((vector_length,3))       # [x y psi]
    PREDICTED_DATA  = np.zeros((vector_length,120))     # [vx vy psidot thetae s ye] presicted to N steps
    TLAPTIME        = np.zeros((30,1))
    ELAPSD_TIME     = np.zeros((vector_length,1))
    CONTROL_ACTIONS = np.zeros((vector_length,2))

    IDENT_DATA      = np.zeros((vector_length,5))
    Data_for_RMSE   = np.zeros((vector_length,4))

    #References      = np.array([ 0.0, 0.0, 0.0, 1.0 ])

    # Loop running at loop rate
    TimeCounter     = 0
    PlannerCounter  = 0
    count           = True
    index           = 0
    start_LapTimer  = datetime.datetime.now()

    insideTrack     = 1

    rospy.sleep(1)   # Soluciona los problemas de inicializacion esperando a que el estimador se inicialice bien

    SS              = 0


###----------------------------------------------------------------###
    ### PATH TRACKING TUNING:
    # ### 33 ms - 7 Hp
    # Q  = 0.6 * np.diag([400.0, 1.0, 1.0, 20.0, 0.0, 600.0])
    # R  = 0.1 * np.diag([1.0, 3.0])  # delta, a
    # dR = 0.3 * np.array([100.0, 300.0])  # Input rate cost u
    # Controller  = PathFollowingLPV_MPC(Q, R, dR, N, Vx_ref, dt, map, "OSQP", Steering_Delay, Velocity_Delay)

    ### 100 ms - 3 Hp
    Q  = 0.3 * np.diag([30.0, 0.001, 0.001, 1.0, 0.0, 60.0])
    R  = 0.2 * np.diag([1.0, 1.0])  # delta, a
    dR = 0.5 * np.array([1.0, 1.0])  # Input rate cost u
    Controller  = PathFollowingLPV_MPC(Q, R, dR, N, Vx_ref, dt, "OSQP", Steering_Delay, Velocity_Delay)

    # ### 66 ms - 4 Hp
    # Q  = 0.7 * np.diag([30.0, 0.001, 0.001, 1.0, 0.0, 70.0])
    # R  = 0.3 * np.diag([3.0, 1.0])  # delta, a
    # dR = 0.5 * np.array([2, 1.0])  # Input rate cost u
    # Controller  = PathFollowingLPV_MPC(Q, R, dR, N, Vx_ref, dt, map, "OSQP", Steering_Delay, Velocity_Delay)

    # ### RACING TAJECTORY TRACKING TUNING:
    # ### 33 ms - 20 Hp
    # Q  = np.diag([400.0, 1.0, 1.0, 20.0, 0.0, 1100.0])
    # R  = 0.0 * np.diag([1.0, 1.0])    # delta, a
    # dR =  np.array([ 100.0, 45.0 ])  # Input rate cost u
    # # dR =  np.array([ 10.0, 10.0 ])  # Input rate cost u
    # Controller_TT  = PathFollowingLPV_MPC(Q, R, dR, N, Vx_ref, dt, "OSQP", Steering_Delay, Velocity_Delay)

###----------------------------------------------------------------###

    L_LPV_States_Prediction = np.zeros((N,6))
    LPV_States_Prediction   = np.zeros((N,6))

    while (not rospy.is_shutdown()) and RunController == 1:

        if planning_data.ready == 0: # wait until the plan is online
            rate.sleep()
        else:    
            # Read Measurements
            GlobalState[:] = estimatorData.CurrentState  # The current estimated state vector [vx vy w x y psi]
            LocalState[:]  = estimatorData.CurrentState  # [vx vy w x y psi]

            if LocalState[0] < 0.01:
                LocalState[0] = 0.01

            GlobalState[5] = wrap(GlobalState[5])
            #print("new_Ref: ",new_Ref)
            #References  = np.vstack(( References, np.transpose(new_Ref) ))

            # max_window = 0

            # if index <= max_window:
            #     if index == 0:
            #         X_REF_vector    = planning_data.x_d[0:N+max_window]
            #         Y_REF_vector    = planning_data.y_d[0:N+max_window]
            #         YAW_REF_vector  = planning_data.psi_d[0:N+max_window]
            #         VEL_REF_vector  = planning_data.vx_d[0:N+max_window]
            #         CURV_REF_vector = planning_data.curv_d[0:N+max_window]

            #     x_ref       = X_REF_vector[index:index+N]
            #     y_ref       = Y_REF_vector[index:index+N]
            #     yaw_ref     = YAW_REF_vector[index:index+N]
            #     vel_ref     = VEL_REF_vector[index:index+N]
            #     curv_ref    = CURV_REF_vector[index:index+N]
            #     index += 1
            # else:
            #     index = 0

            # LocalState[4], Xerror, LocalState[3], LocalState[5] = Body_Frame_Errors(GlobalState[3],
            #      GlobalState[4], GlobalState[5], x_ref[0], y_ref[0], yaw_ref[0], SS, LocalState[0],
            #      LocalState[1], curv_ref[0], dt )

            # Assuming that the system sends us the plan centered on the vehicle 
            # x_ref       = planning_data.x_d[0:N]
            # y_ref       = planning_data.y_d[0:N]
            # yaw_ref     = wrap(planning_data.psi_d[0:N])
            # vel_ref     = planning_data.vx_d[0:N]
            # curv_ref    = planning_data.curv_d[0:N]

            # asuming that we get the whole plan 

            x_ref       = planning_data.x_d[PlannerCounter:PlannerCounter+N]
            y_ref       = planning_data.y_d[PlannerCounter:PlannerCounter+N]
            yaw_ref     = planning_data.psi_d[PlannerCounter:PlannerCounter+N]
            yaw_ref[0]  = wrap(yaw_ref[0])
            vel_ref     = planning_data.vx_d[PlannerCounter:PlannerCounter+N]
            curv_ref    = planning_data.curv_d[PlannerCounter:PlannerCounter+N]

            LocalState[4], Xerror, LocalState[3], LocalState[5] = Body_Frame_Errors(GlobalState[3],
                 GlobalState[4], GlobalState[5], x_ref[0], y_ref[0], yaw_ref[0], SS, LocalState[0],
                 LocalState[1], curv_ref[0], dt ) 

            SS = LocalState[4]  # Aunque parezca que no, esto es necesario

            startTimer = datetime.datetime.now()

            oldU = uApplied
            uApplied = np.array([u_steer, u_acc])

            Controller.OldSteering.append(u_steer) # meto al final del vector
            Controller.OldAccelera.append(u_acc)
            Controller.OldSteering.pop(0)
            Controller.OldAccelera.pop(0)

            new_Ref     = np.array([ planning_data.x_d[0], planning_data.y_d[0], planning_data.psi_d[0], planning_data.vx_d[0], planning_data.curv_d[0] ])

            if u_steer is None or u_acc is None : # deal with possible MPC problems
                u_steer = Controller.OldSteering[-1]
                u_acc = Controller.OldAccelera[-1]

            ## Parse from cmd to cmd_car -> IDIADA

            cmd_car.left_steer_turn_radius_reciprocal_command=u_steer
            
            if  u_acc >= 0:
                cmd_car.acceleration_command = u_acc
                cmd_car.brake_deceleration_command = 0
            else:
                cmd_car.acceleration_command = 0
                cmd_car.brake_deceleration_command = -u_acc

            ## Publish input ###
            input_commands.publish(cmd_car)

            # ### Simulator

            # cmd.servo = u_steer
            # cmd.motor = u_acc
            # input_commands.publish(cmd)

            ###################################################################################################
            ###################################################################################################

            if first_it < 10:
            
                #print('Iteration = ', first_it)
                #vel_ref     = Vx_ref * np.ones(N)
                accel_rate = 0.4
                # xx, uu      = predicted_vectors_generation(N, LocalState, accel_rate, dt)
                xx, uu      = predicted_vectors_generation_V2(N, LocalState, accel_rate, dt)
                Controller.solve(LocalState[0:6], xx, uu, NN_LPV_MPC, vel_ref,curv_ref , 0, 0, 0, first_it)
                print('vel_ref: ',vel_ref,'curv_ref: ',curv_ref)
                print('---> Controller.uPred = ', Controller.uPred[0,:])
                print first_it
                first_it    = first_it + 1


                Controller.OldPredicted = np.hstack((Controller.OldSteering[0:len(Controller.OldSteering)-1], Controller.uPred[Controller.steeringDelay:Controller.N,0]))
                Controller.OldPredicted = np.concatenate((np.matrix(Controller.OldPredicted).T, np.matrix(Controller.uPred[:,1]).T), axis=1)

            else:

                NN_LPV_MPC  = False     

                LPV_States_Prediction, A_L, B_L, C_L = Controller.LPVPrediction(LocalState[0:6], Controller.uPred, vel_ref, curv_ref, Cf_new, LapNumber)

                Controller.solve(LPV_States_Prediction[0,:], LPV_States_Prediction, Controller.uPred, NN_LPV_MPC, vel_ref,curv_ref, A_L, B_L, C_L, first_it)

                print('vel_ref: ',vel_ref,'curv_ref: ',curv_ref)
                # IDENT_DATA[Counter,:] = [LocalState[0], LocalState[1], LocalState[2], uApplied[0], uApplied[1]]

                print('---> Controller.uPred = ', Controller.uPred[0,:])

                # plt.clf()
                # plt.figure(1)
                # plt.plot(Controller.uPred[:,0], 'k-', label='steering')
                # plt.plot(Controller.uPred[:,1], 'c-', label='accel.')
                # plt.legend(loc='best')
                # plt.show()
                # plt.grid()

                Controller_TT.uPred = Controller.uPred

            ###################################################################################################
            ###################################################################################################


            if first_it > 19:
                new_LPV_States_Prediction = LPV_States_Prediction[0, :]
                for i in range(1,N):
                    new_LPV_States_Prediction = np.hstack((new_LPV_States_Prediction, LPV_States_Prediction[i,:]))
                PREDICTED_DATA[Counter,:] = new_LPV_States_Prediction

            if LapNumber == 0:
                # Model delay with an small horizon? 
                u_steer = Controller.uPred[0 + Controller.steeringDelay, 0]
                u_acc = Controller.uPred[0 + Controller.velocityDelay, 1]
            else:
                u_steer = Controller_TT.uPred[0 + Controller.steeringDelay, 0]
                u_acc = Controller_TT.uPred[0 + Controller.velocityDelay, 1]


            CONTROL_ACTIONS[TimeCounter,:] = [u_steer, u_acc]
            ALL_LOCAL_DATA[TimeCounter,:]   = np.hstack((LocalState, uApplied))


            endTimer = datetime.datetime.now();
            deltaTimer = endTimer - startTimer

            ClosedLoopData.addMeasurement(GlobalState, LocalState, uApplied, Counter, deltaTimer.total_seconds())
            ELAPSD_TIME[Counter,:] = deltaTimer.total_seconds()

            TimeCounter     += 1
            PlannerCounter  += 1

            #if PlannerCounter > 9999999:
            if PlannerCounter + N == len(planning_data.x_d)-1: #termina condition for simulation
                u_steer = 0
                u_acc = 0

                #IDIADA
                cmd_car.acceleration_command = u_acc
                cmd_car.brake_deceleration_command = u_acc
                cmd_car.left_steer_turn_radius_reciprocal_command = u_steer
                input_commands.publish(cmd_car)

                # #simulator
                # cmd.servo = u_steer
                # cmd.motor = u_acc
                # input_commands.publish(cmd)

                # Data acquisition tools ->
                # day         = '31_7_19'
                # num_test    = 'Test_1'
                # newpath     = '/home/euge/GitHub/barc/results_simu_test/'+day+'/'+num_test+'/'
                # if not os.path.exists(newpath):
                #     os.makedirs(newpath)
                # np.savetxt(newpath+'/ALL_LOCAL_DATA.dat', ALL_LOCAL_DATA, fmt='%.5e')
                # np.savetxt(newpath+'/PREDICTED_DATA.dat', PREDICTED_DATA, fmt='%.5e')
                # np.savetxt(newpath+'/GLOBAL_DATA.dat', GLOBAL_DATA, fmt='%.5e')
                # np.savetxt(newpath+'/References.dat', References, fmt='%.5e')
                # np.savetxt(newpath+'/TLAPTIME.dat', TLAPTIME, fmt='%.5e')
                # np.savetxt(newpath+'/ELAPSD_TIME.dat', ELAPSD_TIME, fmt='%.5e')
                quit()

            Counter  += 1
            rate.sleep()

    # END WHILE

    # Plotting data
    # plt.figure(2)
    # plt.subplot(311)
    # plt.plot(CONTROL_ACTIONS[0:TimeCounter,0], '-')
    # plt.legend(['Steering'], loc='best')
    # plt.grid()
    # plt.subplot(312)
    # plt.plot(CONTROL_ACTIONS[0:TimeCounter,1], '-')
    # plt.legend(['Acceleration'], loc='best')
    # plt.grid()
    # plt.subplot(313)
    # plt.plot(ALL_LOCAL_DATA[0:TimeCounter,5], '-')
    # plt.legend(['Lateral error'], loc='best')
    # plt.grid()
    # plt.show()

    quit()


# ===============================================================================================================================
# ==================================================== END OF MAIN ==============================================================
# ===============================================================================================================================

def Body_Frame_Errors (x, y, psi, xd, yd, psid, s0, vx, vy, curv, dt):

    ex = (x-xd)*np.cos(psid) + (y-yd)*np.sin(psid)

    ey = -(x-xd)*np.sin(psid) + (y-yd)*np.cos(psid)

    epsi = wrap(psi - psid)

    #s = s0 + np.sqrt(vx*vx + vy*vy) * dt
    s = s0 + ( (vx*np.cos(epsi) - vy*np.sin(epsi)) / (1-ey*curv) ) * dt

    return s, ex, ey, epsi



def predicted_vectors_generation(Hp, LocalState, accel_rate, Ts):

    L_f     = rospy.get_param("lf")
    L_r     = rospy.get_param("lr")
    m       = rospy.get_param("m")
    I_z     = rospy.get_param("Iz")
    Cf      = rospy.get_param("Cf")
    Cr      = rospy.get_param("Cr")
    mu      = rospy.get_param("mu")

    vx      = LocalState[0]
    vy      = LocalState[1]
    psiDot  = LocalState[2]

    Accel = 0.1

    Accel   = Accel + np.array([ (accel_rate * i) for i in range(0, Hp)])

    for i in range(0, Hp):

        a_F = 0.0 - arctan((vy + L_f*psiDot)/abs(vx))
        a_R = arctan((- vy + L_r*psiDot)/abs(vx))

        FyF = Cf * a_F
        FyR = Cr * a_R

        ax      = Accel[i] - mu*vx
        ay      = 1.0/m*(FyF*cos(0.0)+FyR)
        vx      += Ts*(ax + psiDot*vy)
        vy      += Ts*(ay - psiDot*vx)
        psiDot  += Ts*(1.0/I_z*(L_f*FyF*cos(0.0) - L_r*FyR))

        s       +=Ts*vx

        ## [vx vy omega theta_e s y_e]
        xx[i,:] = [vx, vy, psiDot, 0.00001, s, 0.001]

        uu[i,:] = [0.0, Accel[i]]

    return xx, uu



def predicted_vectors_generation_V2(Hp, x0, accel_rate, dt):

    Vx      = np.zeros((Hp+1, 1))
    Vx[0]   = x0[0]
    S       = np.zeros((Hp+1, 1))
    S[0]    = 0
    Vy      = np.zeros((Hp+1, 1))
    Vy[0]   = x0[1]
    W       = np.zeros((Hp+1, 1))
    W[0]    = x0[2]
    Ey      = np.zeros((Hp+1, 1))
    Ey[0]   = x0[3]
    Epsi    = np.zeros((Hp+1, 1))
    Epsi[0] = x0[4]

    Accel   = 0.1
    curv    = 0

    for i in range(0, Hp):
        Vy[i+1]      = x0[1]
        W[i+1]       = x0[2]
        Ey[i+1]      = x0[3]
        Epsi[i+1]    = x0[4]

    Accel   = Accel + np.array([ (accel_rate * i) for i in range(0, Hp)])

    for i in range(0, Hp):
        Vx[i+1]    = Vx[i] + Accel[i] * dt
        S[i+1]      = S[i] + ( (Vx[i]*np.cos(Epsi[i]) - Vy[i]*np.sin(Epsi[i])) / (1-Ey[i]*curv) ) * dt


    xx  = np.hstack([ Vx, Vy, W, Ey, Epsi, S])

    uu = np.zeros(( Hp, 1 ))

    return xx, uu



def plotTrajectory(map, ClosedLoop, Complete_Vel_Vect):
    x = ClosedLoop.x
    x_glob = ClosedLoop.x_glob
    u = ClosedLoop.u
    time = ClosedLoop.SimTime
    it = ClosedLoop.iterations
    elapsedTime = ClosedLoop.elapsedTime
    #print elapsedTime

    # plt.figure(3)
    # plt.plot(time[0:it], elapsedTime[0:it, 0])
    # plt.ylabel('Elapsed Time')
    # ax = plt.gca()
    # ax.grid(True)

    # Visualization
    # plt.figure(2)
    # plt.subplot(711)
    # plt.plot(time[0:it], x[0:it, 0], color='b', label='Response')
    # plt.plot(time[0:it], Complete_Vel_Vect[0:it], color='r', label='Reference')
    # plt.ylabel('vx')
    # ax = plt.gca()
    # ax.legend()
    # ax.grid(True)
    # plt.subplot(712)
    # plt.plot(time[0:it], x[0:it, 1])
    # plt.ylabel('vy')
    # ax = plt.gca()
    # ax.grid(True)
    # plt.subplot(713)
    # plt.plot(time[0:it], x[0:it, 2])
    # plt.ylabel('wz')
    # ax = plt.gca()
    # ax.grid(True)
    # plt.subplot(714)
    # plt.plot(time[0:it], x[0:it, 3],'k')
    # plt.ylabel('epsi')
    # ax = plt.gca()
    # ax.grid(True)
    # plt.subplot(715)
    # plt.plot(time[0:it], x[0:it, 5],'k')
    # plt.ylabel('ey')
    # ax = plt.gca()
    # ax.grid(True)
    # plt.subplot(716)
    # plt.plot(time[0:it], u[0:it, 0], 'r')
    # plt.ylabel('steering')
    # ax = plt.gca()
    # ax.grid(True)
    # plt.subplot(717)
    # plt.plot(time[0:it], u[0:it, 1], 'r')
    # plt.ylabel('acc')
    # ax = plt.gca()
    # ax.grid(True)
    # plt.show()



if __name__ == "__main__":

    try:
        main()

    except rospy.ROSInterruptException:
        pass
